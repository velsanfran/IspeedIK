--[[
    IspeedIK
    Author: velsanfran
    Steam: https://steamcommunity.com/profiles/76561199669576555/
    Version: 1.3
]]

AddCSLuaFile()

IspeedIK = IspeedIK or {}
local IK = IspeedIK

-- ============================================================
-- Settings
-- ============================================================
IK.Author = "velsanfran"
IK.Version = "1.3"

IK.ChatCommand = "!speed"
IK.AdminChatCommand = "!speedadmin"
IK.RequireSuperAdmin = false -- true = admin panel only for superadmins

IK.MinMultiplier = 0.5
IK.MaxMultiplier = 3
IK.BaseWalk = 200
IK.BaseRun = 400
IK.BaseJump = 200

-- player size limits
IK.MinSize = 0.5
IK.MaxSize = 10

-- weapons the admin can put into the "loadout for everyone"
IK.Weapons = {
    {"weapon_physgun", "Physgun"},
    {"weapon_physcannon", "Gravity Gun"},
    {"gmod_tool", "Tool Gun"},
    {"gmod_camera", "Camera"},
    {"weapon_crowbar", "Crowbar"},
    {"weapon_stunstick", "Stunstick"},
    {"weapon_pistol", "Pistol"},
    {"weapon_357", ".357"},
    {"weapon_smg1", "SMG"},
    {"weapon_ar2", "AR2"},
    {"weapon_shotgun", "Shotgun"},
    {"weapon_crossbow", "Crossbow"},
    {"weapon_frag", "Grenade"},
    {"weapon_rpg", "RPG"},
}

IK.WeaponNames = {}
for _, entry in ipairs(IK.Weapons) do
    IK.WeaponNames[entry[1]] = entry[2]
end

-- ============================================================
-- Shared
-- ============================================================
function IK.CanUseAdmin(ply)
    if not IsValid(ply) then return false end
    if IK.RequireSuperAdmin then return ply:IsSuperAdmin() end
    return ply:IsAdmin()
end

-- bunny hop: hold jump to keep hopping.
-- Runs on server and client so movement prediction stays smooth.
hook.Add("StartCommand", "IspeedIK.Bunnyhop", function(ply, cmd)
    if not ply:GetNWBool("IspeedIK.Bhop", false) then return end
    if not cmd:KeyDown(IN_JUMP) then return end
    if ply:GetMoveType() ~= MOVETYPE_WALK then return end
    if ply:WaterLevel() > 1 then return end

    if not ply:OnGround() then
        cmd:RemoveKey(IN_JUMP)
    end
end)

-- default player hull and view heights (Source units)
local HULL_WIDTH, HULL_HEIGHT, HULL_DUCK = 16, 72, 36
local VIEW_STAND, VIEW_DUCK, STEP_SIZE = 64, 28, 18

-- sets hull, view height and step size for a player size.
-- Must run on both server and client, otherwise movement prediction jitters.
function IK.ApplyHull(ply, size)
    if size == 1 then
        ply:ResetHull()
        ply:SetViewOffset(Vector(0, 0, VIEW_STAND))
        ply:SetViewOffsetDucked(Vector(0, 0, VIEW_DUCK))
        ply:SetStepSize(STEP_SIZE)
        return
    end

    local w = HULL_WIDTH * size

    ply:SetHull(Vector(-w, -w, 0), Vector(w, w, HULL_HEIGHT * size))
    ply:SetHullDuck(Vector(-w, -w, 0), Vector(w, w, HULL_DUCK * size))
    ply:SetViewOffset(Vector(0, 0, VIEW_STAND * size))
    ply:SetViewOffsetDucked(Vector(0, 0, VIEW_DUCK * size))
    ply:SetStepSize(STEP_SIZE * size)
end

-- ============================================================
-- Server
-- ============================================================
if SERVER then
    util.AddNetworkString("IspeedIK.Open")
    util.AddNetworkString("IspeedIK.Request")
    util.AddNetworkString("IspeedIK.Apply")
    util.AddNetworkString("IspeedIK.Size")
    util.AddNetworkString("IspeedIK.AdminOpen")
    util.AddNetworkString("IspeedIK.AdminRequest")
    util.AddNetworkString("IspeedIK.AdminInvisible")
    util.AddNetworkString("IspeedIK.AdminSave")
    util.AddNetworkString("IspeedIK.AdminGiveAll")

    local LOADOUT_FILE = "ispeedik_loadout.json"
    local loadout = {} -- set: weapon class -> true

    local function LoadLoadout()
        loadout = {}

        local raw = file.Read(LOADOUT_FILE, "DATA")
        local data = raw and util.JSONToTable(raw)
        if not istable(data) then return end

        for _, class in ipairs(data) do
            -- only known weapons are accepted
            if isstring(class) and IK.WeaponNames[class] then
                loadout[class] = true
            end
        end
    end

    local function LoadoutToList()
        local list = {}

        for _, entry in ipairs(IK.Weapons) do
            if loadout[entry[1]] then
                list[#list + 1] = entry[1]
            end
        end

        return list
    end

    local function SaveLoadout()
        file.Write(LOADOUT_FILE, util.TableToJSON(LoadoutToList()))
    end

    LoadLoadout()

    local function OnCooldown(ply, key, delay)
        local now = CurTime()
        if (ply[key] or 0) > now then return true end

        ply[key] = now + delay
        return false
    end

    -- ---------------- movement ----------------
    local function ApplyMultipliers(ply)
        local speed = ply.ikSpeed or 1
        local jump = ply.ikJump or 1

        ply:SetWalkSpeed(IK.BaseWalk * speed)
        ply:SetRunSpeed(IK.BaseRun * speed)
        ply:SetJumpPower(IK.BaseJump * jump)
    end

    -- ---------------- player size ----------------
    local function ClampValue(value, min, max)
        if value ~= value then return 1 end -- NaN guard

        return math.Clamp(value, min, max)
    end

    -- if the bigger hull ends up inside a wall or floor, lift the player up
    local function Unstick(ply)
        local mins, maxs = ply:GetHull()
        local pos = ply:GetPos()

        local function IsBlocked(at)
            return util.TraceHull({
                start = at,
                endpos = at,
                mins = mins,
                maxs = maxs,
                filter = ply,
                mask = MASK_PLAYERSOLID,
            }).StartSolid
        end

        if not IsBlocked(pos) then return end

        for i = 1, 40 do
            local test = pos + Vector(0, 0, i * 8)

            if not IsBlocked(test) then
                ply:SetPos(test)
                return
            end
        end
    end

    local function ApplySize(ply)
        local size = ply.ikSize or 1

        ply:SetModelScale(size, 0)
        IK.ApplyHull(ply, size)
        Unstick(ply)
    end

    local function SendOpen(ply)
        net.Start("IspeedIK.Open")
            net.WriteFloat(ply.ikSpeed or 1)
            net.WriteFloat(ply.ikJump or 1)
            net.WriteBool(ply.ikBhop == true)
        net.Send(ply)
    end

    -- ---------------- admin tools ----------------
    local function SetInvisible(ply, state)
        ply.ikInvisible = state

        ply:SetNoDraw(state)
        ply:DrawShadow(not state)
        ply:SetNoTarget(state)

        for _, wep in ipairs(ply:GetWeapons()) do
            wep:SetNoDraw(state)
        end
    end

    local function GiveLoadout(ply)
        if not IsValid(ply) or not ply:Alive() then return end

        for class in pairs(loadout) do
            if not ply:HasWeapon(class) then
                ply:Give(class)
            end
        end
    end

    local function SendAdminOpen(ply)
        net.Start("IspeedIK.AdminOpen")
            net.WriteBool(ply.ikInvisible == true)
            net.WriteString(util.TableToJSON(LoadoutToList()))
        net.Send(ply)
    end

    -- ---------------- chat commands ----------------
    hook.Add("PlayerSay", "IspeedIK.ChatCommand", function(ply, text)
        local command = string.lower(string.Trim(text))

        if command == IK.ChatCommand then
            SendOpen(ply)
            return ""
        end

        if command == IK.AdminChatCommand then
            if IK.CanUseAdmin(ply) then
                SendAdminOpen(ply)
            end
            return ""
        end
    end)

    -- ---------------- player menu ----------------
    net.Receive("IspeedIK.Request", function(_, ply)
        if OnCooldown(ply, "ikNextRequest", 0.3) then return end

        SendOpen(ply)
    end)

    net.Receive("IspeedIK.Apply", function(_, ply)
        -- never trust the client, clamp on the server
        local speed = net.ReadFloat()
        local jump = net.ReadFloat()
        local bhop = net.ReadBool()

        ply.ikSpeed = ClampValue(speed, IK.MinMultiplier, IK.MaxMultiplier)
        ply.ikJump = ClampValue(jump, IK.MinMultiplier, IK.MaxMultiplier)
        ply.ikBhop = bhop

        ply:SetNWBool("IspeedIK.Bhop", bhop)
        ApplyMultipliers(ply)
    end)

    net.Receive("IspeedIK.Size", function(_, ply)
        if OnCooldown(ply, "ikNextSize", 0.2) then return end

        local size = ClampValue(net.ReadFloat(), IK.MinSize, IK.MaxSize)

        ply.ikSize = size
        ply:SetNWFloat("IspeedIK.Size", size)
        ApplySize(ply)
    end)

    -- ---------------- admin menu ----------------
    net.Receive("IspeedIK.AdminRequest", function(_, ply)
        if not IK.CanUseAdmin(ply) then return end
        if OnCooldown(ply, "ikNextAdminRequest", 0.3) then return end

        SendAdminOpen(ply)
    end)

    net.Receive("IspeedIK.AdminInvisible", function(_, ply)
        if not IK.CanUseAdmin(ply) then return end

        SetInvisible(ply, net.ReadBool())
    end)

    net.Receive("IspeedIK.AdminSave", function(_, ply)
        if not IK.CanUseAdmin(ply) then return end

        local list = util.JSONToTable(net.ReadString())
        if not istable(list) then list = {} end

        loadout = {}
        for _, class in ipairs(list) do
            if isstring(class) and IK.WeaponNames[class] then
                loadout[class] = true
            end
        end

        SaveLoadout()
    end)

    net.Receive("IspeedIK.AdminGiveAll", function(_, ply)
        if not IK.CanUseAdmin(ply) then return end
        if OnCooldown(ply, "ikNextGiveAll", 1) then return end

        for _, target in ipairs(player.GetAll()) do
            GiveLoadout(target)
        end
    end)

    -- ---------------- spawn handling ----------------
    hook.Add("PlayerSpawn", "IspeedIK.OnSpawn", function(ply)
        -- spawn resets speed and weapons, so wait a moment
        timer.Simple(0.1, function()
            if not IsValid(ply) then return end

            ApplyMultipliers(ply)
            ApplySize(ply)
            GiveLoadout(ply)

            if ply.ikInvisible then
                SetInvisible(ply, true)
            end
        end)
    end)

    hook.Add("WeaponEquip", "IspeedIK.HideWeapon", function(wep, ply)
        if not (IsValid(ply) and ply.ikInvisible) then return end

        timer.Simple(0, function()
            if IsValid(wep) then wep:SetNoDraw(true) end
        end)
    end)

    return
end

-- ============================================================
-- Client
-- ============================================================
local COLOR_FG = Color(90, 255, 130)
local COLOR_DIM = Color(90, 255, 130, 120)
local COLOR_BG = Color(5, 15, 8, 245)
local COLOR_DARK = Color(0, 0, 0)

local BASE_W = 500
local MAIN_H = 300
local ADMIN_H = 350
local SIZE_H = 170
local REFERENCE_HEIGHT = 900

IK.ESP = IK.ESP or false -- wallhack state (admins only, not saved)

-- ------------------------------------------------------------
-- Languages
-- ------------------------------------------------------------
local LANG_ORDER = {"ru", "en", "uk", "be", "de"}
local LANG_LABEL = {ru = "RU", en = "EN", uk = "UA", be = "BY", de = "DE"}

local TEXT = {
    ru = {
        title = "Настройки игрока",
        speed = "Скорость",
        jump = "Прыжок",
        bhop = "Банни хоп",
        admin = "[ Админ ]",
        apply = "[ Применить ]",
        reset = "[ Сбросить ]",
        size = "Размер",
        sizeBtn = "[ Размер ]",
        sizeTitle = "Размер игрока",
        by = "автор",
        adminTitle = "Админ-панель",
        wallhack = "Вх (стены)",
        invisible = "Невидимость",
        loadout = "Набор для всех",
        save = "[ Сохранить ]",
        giveAll = "[ Выдать всем ]",
        saved = "Сохранено",
        given = "Выдано всем",
    },
    en = {
        title = "Player settings",
        speed = "Speed",
        jump = "Jump",
        bhop = "Bunny hop",
        admin = "[ Admin ]",
        apply = "[ Apply ]",
        reset = "[ Reset ]",
        size = "Size",
        sizeBtn = "[ Size ]",
        sizeTitle = "Player size",
        by = "by",
        adminTitle = "Admin panel",
        wallhack = "Wallhack",
        invisible = "Invisible",
        loadout = "Loadout for everyone",
        save = "[ Save ]",
        giveAll = "[ Give to all ]",
        saved = "Saved",
        given = "Given to all",
    },
    uk = {
        title = "Налаштування гравця",
        speed = "Швидкість",
        jump = "Стрибок",
        bhop = "Банні хоп",
        admin = "[ Адмін ]",
        apply = "[ Прийняти ]",
        reset = "[ Скинути ]",
        size = "Розмір",
        sizeBtn = "[ Розмір ]",
        sizeTitle = "Розмір гравця",
        by = "автор",
        adminTitle = "Адмін-панель",
        wallhack = "Вх (стіни)",
        invisible = "Невидимість",
        loadout = "Набір для всіх",
        save = "[ Зберегти ]",
        giveAll = "[ Видати всім ]",
        saved = "Збережено",
        given = "Видано всім",
    },
    be = {
        title = "Налады гульца",
        speed = "Хуткасць",
        jump = "Скачок",
        bhop = "Банні хоп",
        admin = "[ Адмін ]",
        apply = "[ Прымяніць ]",
        reset = "[ Скінуць ]",
        size = "Памер",
        sizeBtn = "[ Памер ]",
        sizeTitle = "Памер гульца",
        by = "аўтар",
        adminTitle = "Адмін-панэль",
        wallhack = "Вх (сцены)",
        invisible = "Нябачнасць",
        loadout = "Набор для ўсіх",
        save = "[ Захаваць ]",
        giveAll = "[ Выдаць усім ]",
        saved = "Захавана",
        given = "Выдана ўсім",
    },
    de = {
        title = "Einstellungen",
        speed = "Tempo",
        jump = "Sprung",
        bhop = "Bunnyhop",
        admin = "[ Admin ]",
        apply = "[ Anwenden ]",
        reset = "[ Zurück ]",
        size = "Größe",
        sizeBtn = "[ Größe ]",
        sizeTitle = "Spielergröße",
        by = "von",
        adminTitle = "Admin-Menü",
        wallhack = "Wallhack",
        invisible = "Unsichtbar",
        loadout = "Ausrüstung für alle",
        save = "[ Speichern ]",
        giveAll = "[ An alle ]",
        saved = "Gespeichert",
        given = "An alle verteilt",
    },
}

-- "auto" = follow the game language, or ru / en / uk / be / de
local langVar = CreateClientConVar("ispeedik_lang", "auto", true, false, "Menu language: auto, ru, en, uk, be, de")

local function GetLang()
    local code = langVar:GetString():lower()

    if not TEXT[code] then
        local gameLang = GetConVar("gmod_language")
        code = gameLang and gameLang:GetString():lower() or "en"
    end

    return TEXT[code] and code or "en"
end

local function T(key)
    return TEXT[GetLang()][key] or TEXT.en[key] or key
end

-- ------------------------------------------------------------
-- Scaling
-- ------------------------------------------------------------
-- manual size multiplier on top of the automatic scaling
local sizeVar = CreateClientConVar("ispeedik_size", "1", true, false, "Menu size multiplier", 0.5, 1.5)

local function GetScale()
    local auto = ScrH() / REFERENCE_HEIGHT

    -- the biggest window may take at most 90% of width and height
    local maxScale = math.min(
        ScrW() * 0.9 / BASE_W,
        ScrH() * 0.9 / math.max(MAIN_H, ADMIN_H)
    )

    return math.min(auto * sizeVar:GetFloat(), maxScale)
end

local function S(n)
    return math.max(1, math.Round(n * GetScale()))
end

local function CreateFonts()
    surface.CreateFont("IspeedIK.Font", {
        font = "Courier New",
        size = math.max(12, S(22)),
        weight = 600,
    })

    surface.CreateFont("IspeedIK.Item", {
        font = "Courier New",
        size = math.max(11, S(15)),
        weight = 600,
    })

    surface.CreateFont("IspeedIK.Small", {
        font = "Courier New",
        size = math.max(10, S(12)),
        weight = 600,
    })
end

-- ------------------------------------------------------------
-- Widgets
-- ------------------------------------------------------------
-- min / max default to the speed range.
-- logarithmic = true gives finer control near small values (used for player size).
local function CreateSlider(parent, labelKey, y, value, min, max, logarithmic)
    min = min or IK.MinMultiplier
    max = max or IK.MaxMultiplier

    local slider = vgui.Create("DPanel", parent)
    slider:SetPos(S(20), S(y))
    slider:SetSize(S(460), S(30))
    slider.Value = math.Clamp(value, min, max)

    local function ToFraction(v)
        if logarithmic then
            return math.log(v / min) / math.log(max / min)
        end

        return (v - min) / (max - min)
    end

    local function FromFraction(frac)
        if logarithmic then
            return min * (max / min) ^ frac
        end

        return Lerp(frac, min, max)
    end

    function slider:Paint(w, h)
        local trackX, trackW = S(150), S(220)
        local frac = math.Clamp(ToFraction(self.Value), 0, 1)

        draw.SimpleText(T(labelKey), "IspeedIK.Font", 0, h / 2, COLOR_FG, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        surface.SetDrawColor(COLOR_FG)
        surface.DrawOutlinedRect(trackX, h / 2 - S(6), trackW, S(12))
        surface.DrawRect(trackX + frac * trackW - S(5), h / 2 - S(10), S(10), S(20))

        draw.SimpleText(string.format("%.1fx", self.Value), "IspeedIK.Font", S(390), h / 2, COLOR_FG, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    function slider:OnMousePressed()
        self:MouseCapture(true)
        self.dragging = true
    end

    function slider:OnMouseReleased()
        self:MouseCapture(false)
        self.dragging = false
    end

    function slider:Think()
        if not self.dragging then return end

        local x = self:CursorPos()
        local frac = math.Clamp((x - S(150)) / S(220), 0, 1)
        self.Value = math.Clamp(math.Round(FromFraction(frac), 1), min, max)
    end

    return slider
end

-- text: string or function returning a string
-- isActive: optional function, a true result keeps the button highlighted
-- font: optional font name
local function CreateButton(parent, text, x, y, w, h, onClick, isActive, font)
    local button = vgui.Create("DButton", parent)
    button:SetPos(S(x), S(y))
    button:SetSize(S(w), S(h))
    button:SetText("")

    function button:Paint(bw, bh)
        local label = isfunction(text) and text() or text
        local filled = self:IsHovered() or (isActive and isActive())

        if filled then
            surface.SetDrawColor(COLOR_FG)
            surface.DrawRect(0, 0, bw, bh)
        end

        surface.SetDrawColor(COLOR_FG)
        surface.DrawOutlinedRect(0, 0, bw, bh)
        draw.SimpleText(label, font or "IspeedIK.Font", bw / 2, bh / 2, filled and COLOR_DARK or COLOR_FG, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    button.DoClick = onClick
    return button
end

local function CreateFrame(width, height)
    local frame = vgui.Create("DFrame")
    frame:SetSize(S(width), S(height))
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:MakePopup()

    return frame
end

local function PaintFrameBackground(w, h)
    surface.SetDrawColor(COLOR_BG)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(COLOR_FG)
    surface.DrawOutlinedRect(0, 0, w, h, 2)
end

local function SendSettings(state)
    net.Start("IspeedIK.Apply")
        net.WriteFloat(state.speed)
        net.WriteFloat(state.jump)
        net.WriteBool(state.bhop)
    net.SendToServer()
end

local function RequestAdminMenu()
    net.Start("IspeedIK.AdminRequest")
    net.SendToServer()
end

-- ------------------------------------------------------------
-- Admin menu
-- ------------------------------------------------------------
local function SendLoadout(selected)
    local list = {}

    for _, entry in ipairs(IK.Weapons) do
        if selected[entry[1]] then
            list[#list + 1] = entry[1]
        end
    end

    net.Start("IspeedIK.AdminSave")
        net.WriteString(util.TableToJSON(list))
    net.SendToServer()
end

local function OpenAdminMenu(invisible, loadoutList)
    if IsValid(IK.AdminFrame) then IK.AdminFrame:Remove() end

    CreateFonts()

    local selected = {}
    for _, class in ipairs(loadoutList) do
        selected[class] = true
    end

    local statusText, statusUntil = "", 0

    local function ShowStatus(key)
        statusText = T(key)
        statusUntil = CurTime() + 2
    end

    local frame = CreateFrame(BASE_W, ADMIN_H)
    IK.AdminFrame = frame

    function frame:Paint(w, h)
        PaintFrameBackground(w, h)

        draw.SimpleText(T("adminTitle"), "IspeedIK.Font", w / 2, S(28), COLOR_FG, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(T("loadout"), "IspeedIK.Font", S(20), S(100), COLOR_FG, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        if CurTime() < statusUntil then
            draw.SimpleText(statusText, "IspeedIK.Font", w / 2, S(332), COLOR_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    CreateButton(frame, "X", 462, 8, 30, 28, function()
        frame:Close()
    end)

    -- wallhack (client side, only for admins)
    CreateButton(frame, function()
        return (IK.ESP and "[x] " or "[ ] ") .. T("wallhack")
    end, 20, 52, 224, 28, function()
        IK.ESP = not IK.ESP
    end, function()
        return IK.ESP
    end)

    -- invisibility (server side)
    CreateButton(frame, function()
        return (invisible and "[x] " or "[ ] ") .. T("invisible")
    end, 256, 52, 224, 28, function()
        invisible = not invisible

        net.Start("IspeedIK.AdminInvisible")
            net.WriteBool(invisible)
        net.SendToServer()
    end, function()
        return invisible
    end)

    -- loadout grid: 3 columns
    for i, entry in ipairs(IK.Weapons) do
        local class, name = entry[1], entry[2]
        local col = (i - 1) % 3
        local row = math.floor((i - 1) / 3)

        CreateButton(frame, function()
            return (selected[class] and "[x] " or "[ ] ") .. name
        end, 20 + col * 156, 116 + row * 30, 148, 26, function()
            selected[class] = not selected[class] or nil
        end, function()
            return selected[class]
        end, "IspeedIK.Item")
    end

    CreateButton(frame, function() return T("save") end, 20, 274, 210, 38, function()
        SendLoadout(selected)
        ShowStatus("saved")
    end)

    CreateButton(frame, function() return T("giveAll") end, 270, 274, 210, 38, function()
        -- save first so everyone gets exactly what is ticked
        SendLoadout(selected)

        net.Start("IspeedIK.AdminGiveAll")
        net.SendToServer()

        ShowStatus("given")
    end)
end

-- ------------------------------------------------------------
-- Size menu
-- ------------------------------------------------------------
local function SendSize(size)
    net.Start("IspeedIK.Size")
        net.WriteFloat(size)
    net.SendToServer()
end

local function OpenSizeMenu()
    if IsValid(IK.SizeFrame) then IK.SizeFrame:Remove() end

    CreateFonts()

    local frame = CreateFrame(BASE_W, SIZE_H)
    IK.SizeFrame = frame

    function frame:Paint(w, h)
        PaintFrameBackground(w, h)

        draw.SimpleText(T("sizeTitle"), "IspeedIK.Font", w / 2, S(28), COLOR_FG, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local current = LocalPlayer():GetNWFloat("IspeedIK.Size", 1)
    local sizeSlider = CreateSlider(frame, "size", 70, current, IK.MinSize, IK.MaxSize, true)

    CreateButton(frame, "X", 462, 8, 30, 28, function()
        frame:Close()
    end)

    CreateButton(frame, function() return T("apply") end, 20, 114, 210, 38, function()
        SendSize(sizeSlider.Value)
    end)

    CreateButton(frame, function() return T("reset") end, 270, 114, 210, 38, function()
        sizeSlider.Value = 1
        SendSize(1)
    end)
end

-- ------------------------------------------------------------
-- Player menu
-- ------------------------------------------------------------
local OpenMenu

local function ChangeSize(delta, state)
    sizeVar:SetFloat(math.Clamp(math.Round(sizeVar:GetFloat() + delta, 1), 0.5, 1.5))
    OpenMenu(state)
end

-- state: {speed = number, jump = number, bhop = boolean}
function OpenMenu(state)
    if IsValid(IK.Frame) then IK.Frame:Remove() end

    CreateFonts()

    local bhop = state.bhop == true

    local frame = CreateFrame(BASE_W, MAIN_H)
    IK.Frame = frame

    function frame:Paint(w, h)
        PaintFrameBackground(w, h)

        draw.SimpleText(T("title"), "IspeedIK.Font", w / 2, S(28), COLOR_FG, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local speedSlider = CreateSlider(frame, "speed", 70, state.speed)
    local jumpSlider = CreateSlider(frame, "jump", 108, state.jump)

    local function Snapshot()
        return {
            speed = speedSlider.Value,
            jump = jumpSlider.Value,
            bhop = bhop,
        }
    end

    -- size and close buttons (top right)
    CreateButton(frame, "-", 390, 8, 30, 28, function()
        ChangeSize(-0.1, Snapshot())
    end)

    CreateButton(frame, "+", 426, 8, 30, 28, function()
        ChangeSize(0.1, Snapshot())
    end)

    CreateButton(frame, "X", 462, 8, 30, 28, function()
        frame:Close()
    end)

    -- row: bunny hop, player size, admin panel (admins only)
    local isAdmin = IK.CanUseAdmin(LocalPlayer())
    local count = isAdmin and 3 or 2
    local gap = 8
    local btnW = (460 - gap * (count - 1)) / count

    CreateButton(frame, function()
        return (bhop and "[x] " or "[ ] ") .. T("bhop")
    end, 20, 146, btnW, 28, function()
        bhop = not bhop
    end, function()
        return bhop
    end, "IspeedIK.Item")

    CreateButton(frame, function() return T("sizeBtn") end, 20 + btnW + gap, 146, btnW, 28, function()
        frame:Close()
        OpenSizeMenu()
    end, nil, "IspeedIK.Item")

    if isAdmin then
        CreateButton(frame, function() return T("admin") end, 20 + (btnW + gap) * 2, 146, btnW, 28, function()
            frame:Close()
            RequestAdminMenu()
        end, nil, "IspeedIK.Item")
    end

    -- language row: five buttons, the active one stays highlighted
    local langW, langGap = 60, 8
    local startX = (BASE_W - (#LANG_ORDER * langW + (#LANG_ORDER - 1) * langGap)) / 2

    for i, code in ipairs(LANG_ORDER) do
        CreateButton(frame, LANG_LABEL[code], startX + (i - 1) * (langW + langGap), 184, langW, 28, function()
            langVar:SetString(code)
            OpenMenu(Snapshot())
        end, function()
            return GetLang() == code
        end)
    end

    -- action buttons
    CreateButton(frame, function() return T("apply") end, 20, 222, 210, 38, function()
        SendSettings(Snapshot())
        frame:Close()
    end)

    CreateButton(frame, function() return T("reset") end, 270, 222, 210, 38, function()
        speedSlider.Value, jumpSlider.Value = 1, 1
        bhop = false
        SendSettings(Snapshot())
    end)

    -- credits line. Hover over it to find a hidden message.
    local credit = vgui.Create("DPanel", frame)
    credit:SetPos(S(100), S(MAIN_H - 19))
    credit:SetSize(S(300), S(14))

    function credit:Paint(w, h)
        if self:IsHovered() then
            draw.SimpleText("BigBob", "IspeedIK.Small", w / 2, h / 2, COLOR_FG, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText("IspeedIK v" .. IK.Version .. " " .. T("by") .. " " .. IK.Author, "IspeedIK.Small", w / 2, h / 2, COLOR_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end

-- ------------------------------------------------------------
-- Network
-- ------------------------------------------------------------
net.Receive("IspeedIK.Open", function()
    local speed = net.ReadFloat()
    local jump = net.ReadFloat()
    local bhop = net.ReadBool()

    OpenMenu({speed = speed, jump = jump, bhop = bhop})
end)

net.Receive("IspeedIK.AdminOpen", function()
    local invisible = net.ReadBool()
    local list = util.JSONToTable(net.ReadString())

    OpenAdminMenu(invisible, istable(list) and list or {})
end)

-- ------------------------------------------------------------
-- Console commands (bindable)
-- ------------------------------------------------------------
-- toggle: second press closes the menu
concommand.Add("ispeedik_menu", function()
    if IsValid(IK.Frame) then
        IK.Frame:Close()
        return
    end

    net.Start("IspeedIK.Request")
    net.SendToServer()
end)

concommand.Add("ispeedik_admin", function()
    if IsValid(IK.AdminFrame) then
        IK.AdminFrame:Close()
        return
    end

    if not IK.CanUseAdmin(LocalPlayer()) then return end

    RequestAdminMenu()
end)

-- ------------------------------------------------------------
-- Wallhack (admins only)
-- ------------------------------------------------------------
local function GetESPTargets()
    local me = LocalPlayer()
    local list = {}

    for _, ply in ipairs(player.GetAll()) do
        if ply ~= me and ply:Alive() and not ply:IsDormant() then
            list[#list + 1] = ply
        end
    end

    return list
end

hook.Add("PreDrawHalos", "IspeedIK.ESP", function()
    if not IK.ESP or not IK.CanUseAdmin(LocalPlayer()) then return end

    halo.Add(GetESPTargets(), COLOR_FG, 2, 2, 2, true, true)
end)

hook.Add("HUDPaint", "IspeedIK.ESPLabels", function()
    if not IK.ESP or not IK.CanUseAdmin(LocalPlayer()) then return end

    for _, ply in ipairs(GetESPTargets()) do
        local top = ply:GetPos() + Vector(0, 0, ply:OBBMaxs().z + 10)
        local pos = top:ToScreen()

        if pos.visible then
            draw.SimpleText(ply:Nick() .. "  " .. ply:Health(), "DermaDefaultBold", pos.x, pos.y, COLOR_FG, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        end
    end
end)

-- ------------------------------------------------------------
-- Housekeeping
-- ------------------------------------------------------------
-- close menus if the resolution changes while they are open
hook.Add("OnScreenSizeChanged", "IspeedIK.Resize", function()
    if IsValid(IK.Frame) then IK.Frame:Remove() end
    if IsValid(IK.AdminFrame) then IK.AdminFrame:Remove() end
    if IsValid(IK.SizeFrame) then IK.SizeFrame:Remove() end
end)

-- keeps the local hull in sync with the server (prediction) and
-- restores it after a respawn
hook.Add("Think", "IspeedIK.SizeSync", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local size = ply:GetNWFloat("IspeedIK.Size", 1)

    if size == 1 then
        if ply.ikSizeApplied and ply.ikSizeApplied ~= 1 then
            IK.ApplyHull(ply, 1)
            ply.ikSizeApplied = 1
        end

        return
    end

    local _, maxs = ply:GetHull()

    if ply.ikSizeApplied ~= size or math.abs(maxs.z - HULL_HEIGHT * size) > 0.01 then
        IK.ApplyHull(ply, size)
        ply.ikSizeApplied = size
    end
end)
